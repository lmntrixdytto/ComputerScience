# ComputerScience
It is about Computer science exam
